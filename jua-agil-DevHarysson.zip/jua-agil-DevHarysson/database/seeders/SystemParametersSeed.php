<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SystemParametersSeed
 extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('system_parameters')->insert([
            [
                'id' => 1,
                'function_name' => 'menu_group',
                'function_value' => 'Configurações',
            ],
            [
                'id' => 2,
                'function_name' => 'menu_group',
                'function_value' => 'Home',
            ],
        ]);
    }
}
