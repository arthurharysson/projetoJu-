<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ParametersAndPermissionsSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('permissions_params')->insert([
            [
                'id' => 1,
                'name' => 'create_user',
                'description' => 'Criar usuários',
                'route_name' => 'users.store',
                'id_menu_group' => 3
            ],
            [
                'id' => 2,
                'name' => 'create_parameters',
                'description' => 'Criar parâmetros',
                'route_name' => 'permissions.store',
                'id_menu_group' => 3
            ],
            [
                'id' => 3,
                'name' => 'create_group_permissions',
                'description' => 'Criar grupos de permissões',
                'route_name' => 'permissions.storeGroup',
                'id_menu_group' => 3
            ],
            [
                'id' => 4,
                'name' => 'view_dashboard',
                'description' => 'Ver a dashboard do sistema',
                'route_name' => 'dashboard.index',
                'id_menu_group' => 5
            ],
        ]);

        DB::table('permissions_groups')->insert([
            [
                'id' => 1,
                'name' => 'Admin',
                'params' => '1,2,3,4',
            ],
            [
                'id' => 2,
                'name' => 'Desenvolvimento',
                'params' => '1,2,3,4',
            ],
            [
                'id' => 3,
                'name' => 'Operador',
                'params' => '4',
            ],
        ]);
    }
}
