<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PasswordRequestForm extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'hash' => 'required',
            'pass' => 'required|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/',
            'password_confirm' => 'required|same:pass',
        ];
    }

    public function messages()
    {
        return [
            'hash.required' => 'O campo Hash é obrigatório.',
            'pass.required' => 'O campo Senha é obrigatório.',
            'pass.regex' => 'A nova senha deve conter pelo menos 8 caracteres, incluindo letras maiúsculas, letras minúsculas, números e caracteres especiais.',
            'password_confirm.required' => 'O campo Confirmar Senha é obrigatório.',
            'password_confirm.same' => 'As senhas não correspondem.',
        ];
    }
}
