<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\CreatePasswordMail;
use App\Models\PasswordReset;
use App\Models\PermissionsGroups;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class UsersAdminController extends Controller
{
    private $data = array();

    //
    public function index()
    {
        $this->data['level'] = 'Settings';
        $this->data['level2'] = 'Users';

        $this->data['users'] = User::leftJoin('permissions_groups', 'users.id_group', '=', 'permissions_groups.id')->select('users.*', 'permissions_groups.name as name_permission')->get();
        $this->data['groups'] = PermissionsGroups::all();

        return view('users.index', $this->data);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'id_group' => 'required|integer'
        ]);

        if (!$validator->fails()) {
            $name = ucfirst(strtolower($request->name));
            $email = strtolower($request->email);
            $group = $request->id_group;
            $request['situation'] = 1;

            $permissionsGroup = PermissionsGroups::where('id', $group)->first();

            if (!$permissionsGroup) {
                return redirect( route('users.index') )->with('toast_success', 'O grupo de permissão atribuído ao usuário é invalido, por favor selecione um grupo válido!');
            }

            $user = User::create([
                'name' => $name,
                'email' => $email,
                'situation' => 0,
                'id_group' => $group
            ]);

            $hash = md5($request->email.date('Y-m-d H:i:s'));
            PasswordReset::create([
                'email' => $email,
                'token' => $hash,
                'situation' => 1,
            ]);

            $createPassword = new CreatePasswordMail($user, $hash, 'Definição de senha!');

            Log::info('Tentando enviar e-mail para: ' . $email);
            Mail::to($email)->queue($createPassword);
            Log::info('E-mail enfileirado para: ' . $email);

            return redirect( route('users.index') )->with('toast_success', 'Usuário cadastrado com sucesso, em alguns minutos ele receberá um email para definição de senha!');
        } else {
            return redirect( route('users.index') )->with('toast_error', $validator->errors()->first());
        }
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_user' => 'required'
        ]);

        if (isset($request->email)) {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|regex:/(.+)@(.+)\.(.+)/i'
            ]);
        }

        if (!$validator->fails()) {
            $user = User::find($request->id_user);

            if (!$user) {
                return redirect( route('users.index') )->with('toast_error', 'Usuário não localizado!');
            }

            $user->update([
                'situation' => $request->situation,
                'id_group' => $request->id_group_edit,
            ]);

            if ($request->email != $user->email) {
                $user->update([
                    'email' => !empty($request->email) ? strtolower($request->email) : $user->email,
                ]);
                $user->save();
            } else {
                if (empty($user->password)) {
                    $email = strtolower($request->email);

                    $existHash = PasswordReset::where('email', $email)->where('situation', 1)->first()->value('token');

                    $hash = $existHash;
                    if (!$existHash) {
                        $hash = md5($request->email.date('Y-m-d H:i:s'));

                        PasswordReset::create([
                            'email' => $email,
                            'token' => $hash,
                            'situation' => 1,
                        ]);
                    }

                    $createPassword = new CreatePasswordMail($user, $hash, 'Definição de senha!');

                    Log::info('Tentando enviar e-mail para: ' . $email);
                    Mail::to($email)->queue($createPassword);
                    Log::info('E-mail enfileirado para: ' . $email);

                }
            }

            return redirect( route('users.index') )->with('toast_success', 'Usuário editado com sucesso!');
        } else {
            return redirect( route('users.index') )->with('toast_error', $validator->errors()->first());
        }
    }
}
