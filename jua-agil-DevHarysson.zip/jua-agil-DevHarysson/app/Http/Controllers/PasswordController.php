<?php

namespace App\Http\Controllers;

use App\Http\Requests\PasswordRequestForm;
use App\Mail\ResetPasswordMail;
use App\Models\PasswordReset;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class PasswordController extends Controller
{
    //
    public function store(PasswordRequestForm $request)
    {
        $hash = PasswordReset::where('token', $request->hash)->where('situation', 1)->first();
        if (!$hash) {
            return redirect(route('auth.create', $request->hash))->with('toast_error', 'Não foi possível redefinir a senha, tente novamente!');
        }

        $user = User::where('email', $hash->email)->first();

        $user->update([
            'password' => Hash::make($request->pass),
            'situation' => 1,
        ]);

        $hash->update([
            'situation' => 0,
        ]);

        return redirect(route('login'))->with('toast_success', 'Senha definida com sucesso!');
    }

    public function reset(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email'
        ], [
            'email.required' => 'O campo email é obrigatório!',
            'email.email' => 'O campo email deve receber um email!',
        ]);

        if (!$validator->fails()) {

            $email = strtolower($request->email);

            $user = User::where('email', $email)->first();

            if ($user) {
                $hash = md5($request->email.date('Y-m-d H:i:s'));
                PasswordReset::create([
                    'email' => $email,
                    'token' => $hash,
                    'situation' => 1,
                ]);

                $resetPassword = new ResetPasswordMail($user, $hash, 'Redefinição de senha!');

                Mail::to($email)->queue($resetPassword);
            }

            return redirect(route('login'))->with('toast_success', 'Verifique o seu e-mail para a redefinição de senha!');
        } else {
            return redirect(route('auth.reset'))->with('toast_error', $validator->errors()->first());
        }
    }

    public function update(PasswordRequestForm $request)
    {
        $hash = PasswordReset::where('token', $request->hash)->where('situation', 1)->first();
        if (!$hash) {
            return redirect(route('auth.resetPassword', $request->hash))->with('toast_error', 'Não foi possível redefinir a senha, tente novamente!');
        }

        $user = User::where('email', $hash->email)->first();

        $user->update([
            'password' => Hash::make($request->pass),
            'situation' => 1,
        ]);

        $hash->update([
            'situation' => 0,
        ]);

        return redirect(route('login'))->with('toast_success', 'Senha redefinida com sucesso!');
    }
}
