<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Op;
use App\Models\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $user = Auth::user();
        $ops = Op::all();
        $logs = Log::all();
        $operadorProds = DB::table('logs')
            ->join('ops', 'logs.linhaProd', '=', 'ops.linhaProd')
            ->select('ops.operador', DB::raw('SUM(logs.producao) as total_producao'))
            ->groupBy('ops.operador')
            ->get();
        if($user->id_group == 1 || $user->id_group == 2)
            return view('admin.dashboard.index', ['ops' => $ops, 'logs' => $logs, 'user' => $user, 'operadorProds' => $operadorProds]);
        else
            return view('operador.dashboard.index', ['ops' => $ops, 'logs' => $logs, 'user' => $user]);
    }
}