<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Op;
use App\Models\Log;
use App\Models\Justify;
use Illuminate\Support\Facades\Auth;

class OpController extends Controller
{
    public function index() {
        $ops = Op::all();
        $logs = Log::all();
        
        return view('op.index', ['ops' => $ops, 'logs' => $logs]);
    }

    public function create() {
        return view('op.create');
    }

    public function store(Request $request) {
        Op::create($request->all());

        return redirect('/home');
    }

    public function show($linhaProd)
    {
        $user = Auth::user();
        $Op = Op::findOrfail($linhaProd);
        $logs = Log::all();
        $justifies = Justify::all();

        return view('op.show', ['linha' => $Op, 'logs' => $logs, 'user' => $user, 'justifies' => $justifies]);
    }

    public function filtrar(Request $request)
    {
        $query = Op::query();

        if ($request->filled('numero_op')) {
            $query->where('numero_op', $request->numero_op);
        }

        if ($request->filled('status')) {
            if ($request->status == 'NULL') {
                $query->whereNull('status');
            } else {
                $query->where('status', $request->status);
            }
        }

        if ($request->filled('date')) {
            $query->whereDate('date', '>=', $request->date);
        }

        $ops = $query->get();

        return view('op.index', compact('ops'));
    }
}