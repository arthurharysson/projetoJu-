<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\PermissionsGroups;
use App\Models\PermissionsParams;
use App\Models\SystemParameters;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PermissionsController extends Controller
{
    private $data = array();

    public function __construct()
    {
        $this->middleware('verifyPermission')->only('store', 'storeGroup');
    }

    public function index()
    {
        $this->data['level'] = 'Settings';
        $this->data['level2'] = 'Permissions';

        $this->data['menu_groups'] = SystemParameters::where('function_name','menu_group')->orderBy('function_value')->get();

        $this->data['params'] = PermissionsParams::all();
        $this->data['groups'] = PermissionsGroups::all();

        foreach($this->data['menu_groups'] as $group) {
            $group['params'] = PermissionsParams::where('id_menu_group',$group->id)->get()->toArray();
        }

        return view('permissions.index', $this->data);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'description' => 'required',
            'route_name' => 'required',
            'menu_group' => 'required',
        ]);

        if (!$validator->fails()) {

            $parametro = PermissionsParams::where('name', strtolower($request->name))->first();
            if ($parametro) {
                return redirect( route('permission') )->with('toast_error', 'Não é possível criar parâmetros com o mesmo nome!');
            }

            PermissionsParams::create([
                'name' => strtolower($request->name),
                'description' => $request->description,
                'route_name' => $request->route_name,
                'id_menu_group' => $request->menu_group
            ]);

            return redirect( route('permissions.index') )->with('toast_success', 'Parâmetro cadastrado com sucesso!');
        } else {
            return redirect( route('permissions.index') )->with('toast_error', $validator->errors()->first());
        }
    }
    public function storeGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'permissions' => 'required|array',
        ]);

        if (!$validator->fails()) {

            $groups = PermissionsGroups::where('name', 'LIKE', '%' . ucfirst($request->name) . '%')->first();

            if ($groups) {
                return redirect( route('permissions.index') )->with('toast_error', 'Não é possível criar mais de um grupo com o mesmo nome!');
            }

            PermissionsGroups::create([
                'name' => ucfirst($request->name),
                'params' => implode(',', $request->permissions)
            ]);

            return redirect( route('permissions.index') )->with('toast_success', 'Grupo criado com sucesso!');
        } else {
            return redirect( route('permissions.index') )->with('toast_error', $validator->errors()->first());
        }
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_edit' => 'required|integer',
            'name' => 'required',
            'description' => 'required',
            'route_name' => 'required',
            'menu_group' => 'required',
        ]);

        if (!$validator->fails()) {

            $parametro = PermissionsParams::where('id', $request->id_edit)->first();
            if (!$parametro) {
                return redirect( route('permissions.index') )->with('toast_error', 'Parâmetro não encontrado!');
            }

            $parametro->update([
                'name' => strtolower($request->name),
                'description' => $request->description,
                'route_name' => $request->route_name,
                'id_menu_group' => $request->menu_group
            ]);
            $parametro->save();

            return redirect( route('permissions.index') )->with('toast_success', 'Parâmetro cadastrado com sucesso!');
        } else {
            return redirect( route('permissions.index') )->with('toast_error', $validator->errors()->first());
        }
    }

    public function updateGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_edit' => 'required|integer',
            'name' => 'required',
            'permissions' => 'required|array',
        ]);

        if (!$validator->fails()) {
            $id = $request->id_edit;

            $group = PermissionsGroups::find($id);

            if (!$group) {
                return redirect( route('permissions.index') )->with('toast_error', 'Grupo de permissões não encontrado!');
            }

            $group->update([
                'name' => ucfirst($request->name),
                'params' => implode(',', $request->permissions)
            ]);
            $group->save();

            return redirect( route('permissions.index') )->with('toast_success', 'Grupo de permissão atualizado com sucesso!');
        } else {
            return redirect( route('permissions.index') )->with('toast_error', $validator->errors()->first());
        }
    }
}
