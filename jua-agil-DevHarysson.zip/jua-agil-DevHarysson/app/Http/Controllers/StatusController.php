<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Op; // Assumindo que a classe modelo é Op

class StatusController extends Controller
{
    public function updateStatus(Request $request, $id)
    {
        // Validação opcional
        $request->validate([
            'status' => 'required|string',
        ]);

        // Encontra o registro e atualiza o campo 'status'
        $op = Op::findOrFail($id);
        $op->status = $request->input('status');
        $op->save();

        // Redireciona de volta com uma mensagem de sucesso
        return redirect()->back()->with('success', 'Status atualizado com sucesso.');
    }
}

