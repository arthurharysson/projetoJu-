<?php

namespace App\Http\Controllers;

use App\Models\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    private $data = array();

    //
    public function index()
    {
        return view('Auth.index');
    }

    public function login(Request $request)
    {
        if (!Auth::attempt($request->only(['email', 'password']))) {
            return redirect()->back()->withInput()->withErrors(['Usuário ou senha inválido!']);
        }

        return to_route('home');
    }

    public function create($hash)
    {
        $this->data['hash'] = $hash;

        $existHash = PasswordReset::where('token', $hash)->where('situation', 1)->first();
        if (!$existHash) {
            return redirect( route('login') )->with('toast_warning', 'Senha já definida!');
        }

        return view('Auth.create', $this->data);
    }

    public function reset()
    {
        return view('Auth.email', $this->data);
    }

    public function ResetPassword($hash)
    {
        $this->data['hash'] = $hash;

        return view('Auth.reset', $this->data);
    }

    public function logout(Request $request)
    {
        Auth::logout();

        return to_route('login');
    }
}
