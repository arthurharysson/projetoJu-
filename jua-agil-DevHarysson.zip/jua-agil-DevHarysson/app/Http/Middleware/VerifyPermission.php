<?php

namespace App\Http\Middleware;

use App\Models\PermissionsGroups;
use App\Models\PermissionsParams;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class VerifyPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {

        if (auth()->check()) {
            $group = PermissionsGroups::where('id', auth()->user()->id_group)->first();

            if (!$group) {
                return redirect(route('dashboard.index'))->with('toast_error', 'Você não está atribuído a nenhum grupo de permissões, peça que algum administrador o atribua!');
            }

            $users_params = explode(',', $group->params);

            $route_names = array();
            foreach ($users_params as $param) {
                array_push($route_names, PermissionsParams::where('id', $param)->value('route_name'));
            }

            $currentRoute = Route::getCurrentRoute();
            $currentRouteName = $currentRoute ? $currentRoute->getName() : null;

            if (in_array($currentRouteName ,$route_names)) {
                return $next($request);
            } else {

                if (in_array('dashboard.index', $route_names)) {
                    return redirect(route('dashboard.index'))->with('toast_warning', 'Você não possuí acesso a essa página!');
                } else {
                    return redirect(route($route_names[0]));
                }

            }
        }

    }
}
