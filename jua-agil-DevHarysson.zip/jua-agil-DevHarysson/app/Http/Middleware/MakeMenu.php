<?php

namespace App\Http\Middleware;

use App\Models\PermissionsGroups;
use App\Models\PermissionsParams;
use Closure;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class MakeMenu
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {

        if (auth()->check()) {

            session()->forget('menu');

            $group = PermissionsGroups::where('id', auth()->user()->id_group)->first();
            $all_params = PermissionsParams::pluck('name', 'id')->toArray();

            $users_params = explode(',', $group->params);

            $makeMenu = array();
            foreach ($all_params as $key => $value) {
                if (in_array($key, $users_params)) {
                    $makeMenu[$value] = true;
                } else {
                    $makeMenu[$value] = false;
                }
            }
            Session::put('menu', $makeMenu);

            return $next($request);
        } else {
            return redirect(route('logout'));
        }
    }
}
