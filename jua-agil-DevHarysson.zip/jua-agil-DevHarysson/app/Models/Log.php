<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Op;

class Log extends Model
{
    use HasFactory;
    protected $fillable = [
        'verificarParada',
        'producao',
        'retrabalho',
        'horario',
        'linhaProd'
    ];

    protected $dates = ['horario'];
}
