<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Op extends Model
{
    use HasFactory;
    protected $fillable = [
        'numero_op', 
        'codigo', 
        'descricao', 
        'metodo', 
        'numeroLote', 
        'quantidadePrevista', 
        'un',
        'linhaProd',
        'date',
        'time',
        'operador'
    ];
}
