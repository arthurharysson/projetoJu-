<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ResetPasswordMail extends Mailable
{
    use Queueable, SerializesModels;

    private $user;
    private $hash;

    private $data = array();

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $user, $token, $text)
    {
        //
        $this->subject($text);

        $this->user = $user;
        $this->hash = $token;
    }

    // /**
    //  * Get the message envelope.
    //  *
    //  * @return \Illuminate\Mail\Mailables\Envelope
    //  */
    // public function envelope()
    // {
    //     return new Envelope(
    //         subject: $text,
    //     );
    // }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function build()
    {
        $this->data['name'] = $this->user->name;
        $this->data['hash'] = $this->hash;

        return $this->view('mail.resetPasswordMail', [
            'data' => $this->data
        ])->with(['message' => $this]);
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }
}
