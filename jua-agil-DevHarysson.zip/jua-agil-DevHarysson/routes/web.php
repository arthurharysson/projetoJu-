<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\JustifyController;
use App\Http\Controllers\UsersAdminController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\PasswordController;
use App\Http\Controllers\PermissionsController;
use App\Http\Controllers\OpController;
use App\Http\Controllers\StatusController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Mail;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth', 'makeMenu'])->group(function () {

    Route::post('/home/{id}/status', [StatusController::class, 'updateStatus'])->name('status.update');

    Route::get('/home', [DashboardController::class, 'index'])->middleware('auth')->name('home');

    Route::get('/status-linha', [DashboardController::class, 'statusLinha']);

    Route::get('/home/{linhaProd}', [OpController::class, 'show']);

    Route::get('/listar-ops', [OpController::class, 'index']);

    Route::post('/op', [OpController::class, 'store']);

    Route::get('/filtrarOrdens', [OpController::class, 'filtrar'])->name('filtrarOrdens');

    Route::post('/justify', [JustifyController::class, 'store']);

    Route::resource('/users', UsersAdminController::class)->only(['index', 'store', 'update']);

    Route::resource('/permissions', PermissionsController::class)->only(['index', 'store']);
    Route::post('/permissions/newGroup', [PermissionsController::class, 'storeGroup'])->name('permissions.storeGroup');
    Route::put('/permissions/update', [PermissionsController::class, 'update'])->name('permissions.update');
    Route::put('/permissions/updateGroup', [PermissionsController::class, 'updateGroup'])->name('permissions.updateGroup'); 
});
Route::get('/', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('auth.login');
Route::get('/createPass/{hash}', [LoginController::class, 'create'])->name('auth.create');
Route::post('/logout', [LoginController::class, 'logout'])->name('auth.logout');
Route::get('/resetPass', [LoginController::class, 'reset'])->name('auth.reset');
Route::get('/createNewPass/{hash}', [LoginController::class, 'resetPassword'])->name('auth.resetPassword');

Route::post('/passCreate', [PasswordController::class, 'store'])->name('password.store');
Route::post('/sendEmail', [PasswordController::class, 'reset'])->name('password.reset');
Route::post('/updatePassword', [PasswordController::class, 'update'])->name('password.update');


