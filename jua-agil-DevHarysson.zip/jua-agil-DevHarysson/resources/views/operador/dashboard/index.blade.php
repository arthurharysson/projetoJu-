@extends('layouts.default')

@section('content')
    <style>
        /* Centraliza o texto nas tabelas */
        table {
            text-align: center;
        }

        /* Estilo dos labels dos formulários */
        label {
            display: block;
            margin-top: 11px;
            font-weight: bold;
            color: #0079eb;
        }

        /* Estilo dos inputs e selects dos formulários */
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 3px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Estilo do título */
        h1 {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif !important;
            font-size: 35px !important;
            margin-bottom: 20px;
        }

        /* Estilo do corpo do modal */
        .modal-body {
            padding: 20px;
        }

        /* Remove as bordas dos cabeçalhos e rodapés do modal */
        .modal-header, .modal-footer {
            border: none;
        }

        /* Estilo do botão primário */
        .btn-primary {
            background-color: #0079eb;
            border: none;
        }

        /* Margem inferior dos grupos de formulários */
        .form-group {
            margin-bottom: 15px;
        }

        /* Margem inferior das observações */
        .obs {
            margin-bottom: 15px;
        }

        /* Define a largura máxima do conteúdo do modal e centraliza */
        .modal-content {
            max-width: 600px;
            margin: auto;
        }

        td{
        font-weight: bold;
       
        }

        th{
        font-weight: normal;
       
        }

        .icon-legend{
        width: 40%;
        margin-top: 1rem;
    }

        
    </style>

    <div class="row">
        @include('components.breadcrumb.breadcrumb', [
            'title' => 'Painel',
            'links' => [
                [
                    'title' => 'Dashboard',
                    'link' => '#',
                    'active' => false,
                    'is_current' => false,
                ],
                [
                    'title' => 'Index',
                    'link' => '#',
                    'active' => true,
                    'is_current' => true,
                ],
            ],
        ])

        <div class="card">
            <div class="col-12">
                <div class="card-header">
                    <h5 class="card-title mb-0">ORDENS DE PRODUÇÃO CADASTRADAS</h5>
                    <div id="table-icons"> 
                        <table class="icon-legend">
                            <thead>
                                <tr>
                                    <th><i style="color:blue;" class="bi bi-circle-fill"></i></th>
                                    <th><i style="color:#00FF00;" class="bi bi-circle-fill"></i></th>
                                    <th><i style="color:yellow;" class="bi bi-circle-fill"></i></th>
                                    <th><i style="color:red;" class="bi bi-circle-fill"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Ativa</td>
                                    <td>Finalizada</td>
                                    <td>Aguardando</td>
                                    <td>Parada</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>  
                </div>

                

                <div class="card-body">
                <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;" role="grid" aria-describedby="datatables-reponsive_info">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Número da OP</th>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th>Método</th>
                                <th>Lote</th>
                                <th>Quantidade prevista</th>
                                <th>UN</th>
                                <th>Linha de Produção</th>
                                <th>Data/Hora</th>
                                <th>Operador</th>
                                <th>Ações</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($ops as $op)
                                @php
                                    // Obter o último registro relacionado à OP na tabela ops
                                    $lastOp = $ops->where('id', $op->id)->last();

                                    // Obter o último log relacionado à OP
                                    $lastLog = $logs->where('op_id', $op->id)->last();
                                @endphp
                                <tr>
                                    <td>{{ $op->id }}</td>
                                    <td>{{ $op->numero_op }}</td>
                                    <td>{{ $op->codigo }}</td>
                                    <td>{{ $op->descricao }}</td>
                                    <td>{{ $op->metodo }}</td>
                                    <td>{{ $op->numeroLote }}</td>
                                    <td>{{ $op->quantidadePrevista }}</td>
                                    <td>{{ $op->un }}</td>
                                    <td>{{ $op->linhaProd }}</td>
                                    <td>
                                        {{ date('d/m/Y', strtotime($op->date)) }} - 
                                        {{ \Carbon\Carbon::parse($op->time)->format('H:i') }}
                                    </td>
                                    <td>{{ $op->operador }}</td>
                                    <td>
                                        <form method="GET" action="/home/{{$op->id}}">
                                            <button class="btn btn-primary">Detalhar</button>
                                        </form>
                                    </td>
                                    <td>
                                        @if ($lastOp->status == 'ativa')
                                            <i style="color:blue;" class="bi bi-circle-fill"></i>
                                        @elseif ($lastOp->status == 'finalizada')
                                            <i style="color:#00FF00;" class="bi bi-circle-fill"></i>
                                        @elseif (is_null($lastOp->status) && optional($lastLog)->verificarParada == false)
                                            <i style="color:yellow;" class="bi bi-circle-fill"></i>
                                        @endif
                                        @if (optional($lastLog)->verificarParada == true)
                                            <i style="color:red;" class="bi bi-circle-fill"></i>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#ordemModal">
                        Nova Ordem de Produção
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Estrutura do Modal -->
    <div class="modal fade" id="ordemModal" tabindex="-1" role="dialog" aria-labelledby="ordemModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ordemModalLabel">Nova Ordem de Produção</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Formulário dentro do modal -->
                    <form action="/op" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="numero_op">Número da OP</label>
                            <select class="form-control" name="numero_op" id="numero_op">
                                <option selected>Selecione o número da OP</option>
                                <option value="22147">22147</option>
                                <option value="13093">13093</option>
                                <option value="12367">12367</option>
                                <option value="09871">09871</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="codigo">Código</label>
                            <select class="form-control" name="codigo" id="codigo">
                                <option selected>Código</option>
                                <option value="1308">1308</option>
                                <option value="0000">0000</option>
                                <option value="1111">1111</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="metodo">Método</label>
                            <select class="form-control" name="metodo" id="metodo">
                                <option selected>Método</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="numeroLote">Lote de Produção</label>
                            <select class="form-control" name="numeroLote" id="numeroLote">
                                <option selected>Lote de Prod</option>
                                <option value="2401">2401</option>
                                <option value="2100">2100</option>
                                <option value="1223">1223</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="quantidadePrevista">Quantidade prevista</label>
                            <input type="number" class="form-control" name="quantidadePrevista" id="quantidadePrevista" placeholder="Qtd Prev">
                        </div>
                        <div class="form-group">
                            <label for="un">Un</label>
                            <input type="text" class="form-control" name="un" id="un" placeholder="Un:">
                        </div>
                        <div class="form-group">
                            <label for="linhaProd">Linha de produção</label>
                            <select class="form-control" name="linhaProd" id="linhaProd">
                                <option selected>Linha de Produção</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                            </select>
                        </div>
                        <div class="obs">
                            <label for="descricao">Descrição</label>
                            <input type="text" class="form-control" name="descricao" id="descricao" placeholder="Descrição">
                        </div>
                        <div class="obs">
                            <label for="operador">Operador</label>
                            <input type="text" class="form-control" name="operador" id="operador" placeholder="Operador">
                        </div>
                        <div class="data">
                            <label for="date">Data</label>
                            <input type="date" class="form-control" name="date" id="date">
                        </div>
                        <div class="hora">
                            <label for="time">Hora</label>
                            <input type="time" class="form-control" name="time" id="time">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">Cadastrar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
