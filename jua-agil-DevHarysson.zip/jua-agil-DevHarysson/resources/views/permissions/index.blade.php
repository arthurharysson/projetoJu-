@extends('layouts.default')

@section('content')
    @if (session()->has('menu'))
        @php
            $sessao = Session::get('menu');
        @endphp
    @endif

    <div class="row">
        @include('components.breadcrumb.breadcrumb', [
            'title' => 'Permissões',
            'links' => [
                [
                    'title' => 'Configurações',
                    'link' => route('home'),
                    'active' => false,
                    'is_current' => false,
                ],
                [
                    'title' => 'Permissões',
                    'link' => '',
                    'active' => true,
                    'is_current' => true,
                ],
            ],
        ])

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasRightLabel">Novo Parâmetro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body pt-0">
                <form action="{{ route('permissions.store') }}" method="POST">
                    @csrf
                    <div class="form-floating my-3">
                        <input type="text" class="form-control" name="name" id="paramName" placeholder="" required>
                        <label for="paramName">Nome do Parâmetro</label>
                    </div>
                    <div class="form-floating my-3">
                        <input type="text" class="form-control" name="description" id="paramDescription" placeholder=""
                            required>
                        <label for="paramDescription">Descrição do Parâmetro</label>
                    </div>
                    <div class="form-floating my-3">
                        <input type="text" class="form-control" name="route_name" id="route_name" placeholder=""
                            required>
                        <label for="route_name">Nome da Rota</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select class="form-select" id="floatingSelect" name="menu_group"
                            aria-label="Floating label select example">
                            <option value="">Selecione</option>
                            @foreach ($menu_groups as $item)
                                <option value="{{ $item->id }}">{{ $item->function_value }}</option>
                            @endforeach
                        </select>
                        <label for="floatingSelect">Selecione o menu referente a essa permissão</label>
                    </div>
                    <div class="pt-1 d-flex gap-3">
                        <button type="reset" data-bs-dismiss="offcanvas" aria-label="Close"
                            class="btn btn-outline-secondary btn-sm px-3 w-50">Cancelar</button>
                        <button type="submit" class="btn btn-primary w-50 btn-sm px-3">Salvar</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRightEdit"
            aria-labelledby="offcanvasRightEditLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasRightEditLabel">Editar Parâmetro</h5>
                <button type="button" class="btn-close" onclick="closeOffCanvas(this)"
                    data-id="offcanvasRightEdit"></button>
            </div>
            <div class="offcanvas-body pt-0">
                <form action="{{ route('permissions.update') }}" method="POST">
                    @csrf
                    @method('put')
                    <input type="hidden" id="id_edit" name="id_edit">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="name" id="paramNameEdit" placeholder=""
                            required>
                        <label for="paramNameEdit">Nome do Parâmetro</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="description" id="paramDescriptionEdit"
                            placeholder="" required>
                        <label for="paramDescriptionEdit">Descrição do Parâmetro</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="route_name" id="paramRouteNameEdit" placeholder=""
                            required>
                        <label for="paramRouteNameEdit">Nome da Rota</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select class="form-select" id="floatingSelectMenuGroup" name="menu_group"
                            aria-label="Floating label select example">
                            <option value="">Selecione</option>
                            @foreach ($menu_groups as $item)
                                <option value="{{ $item->id }}">{{ $item->function_value }}</option>
                            @endforeach
                        </select>
                        <label for="floatingSelect">Selecione o menu referente a essa permissão</label>
                    </div>
                    <div class="pt-1 d-flex gap-3">
                        <button type="reset" class="btn btn-outline-secondary btn-sm px-3 w-50"
                            onclick="closeOffCanvas(this)" data-bs-dismiss="offcanvas" aria-label="Close"
                            data-id="offcanvasRightEdit">Cancelar</button>
                        <button type="submit" class="btn btn-primary btn-sm w-50 px-3">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title mb-0">Permissões</h5>
                    <div>
                        @if ($sessao['create_parameters'])
                            <button class="btn btn-outline-primary btn-sm" type="button" data-bs-toggle="offcanvas"
                                data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">+ Novo Parâmetro</button>
                        @endif
                        @if ($sessao['create_group_permissions'])
                            <button class="btn btn-outline-primary btn-sm" type="button" data-bs-toggle="offcanvas"
                                data-bs-target="#offcanvasRightTwo" aria-controls="offcanvasRightTwo">+ Novo
                                Grupo</button>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-8">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-0">Parâmetros do sistema</h5>
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Parâmetro</th>
                                                <th scope="col" class="d-none d-md-table-cell">Descrição</th>
                                                <th scope="col" class="d-none d-md-table-cell">Rota</th>
                                                <th scope="col">Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($params as $param)
                                                <tr>
                                                    <th>#</th>
                                                    <td>{{ $param->name }}
                                                        <p class="m-0 d-table-cell d-md-none text-muted">
                                                            {{ $param->description }}</p>
                                                    </td>
                                                    <td class="d-none d-md-table-cell">{{ $param->description }}</td>
                                                    <td class="d-none d-md-table-cell">{{ $param->route_name }}</td>
                                                    <td>
                                                        <button type="button"
                                                            class="border-0 bg-transparent buttonSearchCollection"
                                                            data-id="{{ $param->id }}"
                                                            data-name="{{ $param->name }}"
                                                            data-menu-group="{{ $param->id_menu_group }}"
                                                            data-description="{{ $param->description }}"
                                                            data-route-name="{{ $param->route_name }}"
                                                            onclick="editPermission(this)"><i
                                                                class="bi bi-pencil-square text-primary"
                                                                style="font-size: 16px;"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-0">Grupos de permissões</h5>
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Grupo</th>
                                                <th scope="col">Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($groups as $group)
                                                <tr>
                                                    <th>#</th>
                                                    <td>{{ $group->name }}</td>
                                                    <td>
                                                        <button type="button"
                                                            class="border-0 bg-transparent buttonSearchCollection"
                                                            data-id="{{ $group->id }}"
                                                            data-name="{{ $group->name }}"
                                                            data-params="{{ $group->params }}"
                                                            onclick="editGroup(this)"><i
                                                                class="bi bi-pencil-square text-primary"
                                                                style="font-size: 16px;"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRightTwo"
            aria-labelledby="offcanvasRightLabelTwo">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasRightLabelTwo">Novo Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body pt-0">
                <form action="{{ route('permissions.storeGroup') }}" method="POST">
                    @csrf
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="name" id="paramName" placeholder=""
                            required>
                        <label for="paramName">Nome do Grupo</label>
                    </div>
                    <p class="m-0">Parâmetros:</p>
                    <div class="accordion" id="accordionExampleNew">
                        @foreach ($menu_groups as $param)
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse{{ $param->id }}" aria-expanded="true"
                                        aria-controls="collapse">
                                        {{ $param->function_value }}
                                    </button>
                                </h2>
                                <div id="collapse{{ $param->id }}" class="accordion-collapse collapse"
                                    data-bs-parent="#accordionExampleNew">
                                    <div class="accordion-body">
                                        @foreach ($param->params as $item)
                                            <div class="form-check form-switch">
                                                <input class="form-check-input parameter" name="permissions[]"
                                                    type="checkbox" role="switch" id="param{{ $item['id'] }}"
                                                    value="{{ $item['id'] }}">
                                                <label class="form-check-label"
                                                    for="param{{ $item['id'] }}">{{ $item['description'] }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="pt-3 d-flex gap-3">
                        <button type="reset" data-bs-dismiss="offcanvas" aria-label="Close"
                            class="btn btn-outline-secondary btn-sm px-3 w-50">Cancelar</button>
                        <button type="submit" class="btn btn-primary w-50 btn-sm px-3">Salvar</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRightEditTwo"
            aria-labelledby="offcanvasRightEditLabelTwo">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasRightEditLabelTwo">Editar Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"
                    onclick="closeOffCanvas(this)" data-id="offcanvasRightEditTwo"></button>
            </div>
            <div class="offcanvas-body pt-0">
                <form action="{{ route('permissions.updateGroup') }}" method="POST">
                    @csrf
                    @method('put')
                    <input type="hidden" id="id_group_edit" name="id_edit">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="name" id="groupNameEdit"
                            placeholder="Digite o nome do Parâmetro" required>
                        <label for="paramNameEdit">Nome do Grupo</label>
                    </div>
                    <div class="accordion" id="accordionExample">
                        @foreach ($menu_groups as $param)
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse{{ $param->id }}" aria-expanded="true"
                                        aria-controls="collapse">
                                        {{ $param->function_value }}
                                    </button>
                                </h2>
                                <div id="collapse{{ $param->id }}" class="accordion-collapse collapse"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        @foreach ($param->params as $item)
                                            <div class="form-check form-switch">
                                                <input class="form-check-input parameter" name="permissions[]"
                                                    type="checkbox" role="switch" id="paramEdit{{ $item['id'] }}"
                                                    value="{{ $item['id'] }}">
                                                <label class="form-check-label"
                                                    for="paramEdit{{ $item['id'] }}">{{ $item['description'] }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="pt-1 d-flex gap-3">
                        <button type="reset" class="btn btn-outline-secondary btn-sm px-3 w-50"
                            onclick="closeOffCanvas(this)" data-id="offcanvasRightEditTwo">Cancelar</button>
                        <button type="submit" class="btn btn-primary w-50 btn-sm px-3">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="{{ asset('assets/js/jquery-3.5.1.js') }}" defer></script>
    <script src="{{ asset('assets/js/permissions.js') }}" defer></script>
@endsection
