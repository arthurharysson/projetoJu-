<div class="mb-2 mb-xl-3 d-flex justify-content-between">
    <div class="col-auto d-none d-sm-block">
        <h3 class="text-muted"><strong>{{ $title }}</strong></h3>
    </div>

    <div class="col-auto ms-auto text-end mt-n1">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0 mt-1 mb-0">
                @foreach ($links as $link)
                    <li class="breadcrumb-item {{ $link['active'] ? 'active' : '' }}"
                        {{ $link['is_current'] ? 'aria-current="page"' : '' }}>
                        {!! !empty($link['link']) ? '<a href="'.$link['link'].'">'.$link['title'].'</a>' :  $link['title'] !!}
                    </li>
                @endforeach
            </ol>
        </nav>
    </div>
</div>
