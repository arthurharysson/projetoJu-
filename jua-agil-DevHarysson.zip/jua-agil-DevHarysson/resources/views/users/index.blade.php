@extends('layouts.default')

@section('content')

    @if (session()->has('menu'))
        @php
            $sessao = Session::get('menu');
        @endphp
    @endif

    @if ($sessao['create_user'])
        <div class="modal fade" id="newUser" tabindex="-1" data-bs-keyboard="false" role="dialog" aria-labelledby="modalTitleId"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form action="{{ route('users.store') }}" method="POST">
                        @csrf
                        <div class="modal-header border border-0">
                            <h5 class="modal-title" id="modalTitleId">Novo usuário</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body py-0">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="name" name="name" required
                                    placeholder="Ex: João">
                                <label for="name">Nome</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" name="email" required
                                    placeholder="Ex: Joao@gmail.com">
                                <label for="email">E-mail</label>
                            </div>
                            <div class="form-floating mb-3">
                                <select class="form-select" id="floatingSelect" name="id_group"
                                    aria-label="Floating label select example">
                                    <option value="">Selecione o tipo</option>
                                    @foreach ($groups as $group)
                                        <option value="{{ $group->id }}">{{ $group->name }}</option>
                                    @endforeach
                                </select>
                                <label for="floatingSelect">Grupo de permissão</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-outline-secondary px-3 btn-sm"
                                data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary px-3 btn-sm">Salvar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    <div class="row">
        @include('components.breadcrumb.breadcrumb', [
            'title' => 'Usuários',
            'links' => [
                [
                    'title' => 'Configurações',
                    'link' => route('home'),
                    'active' => false,
                    'is_current' => false,
                ],
                [
                    'title' => 'Usuários',
                    'link' => '',
                    'active' => true,
                    'is_current' => true,
                ],
            ],
        ])
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title mb-0">Usuários</h5>
                    @if ($sessao['create_user'])
                        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal"
                        data-bs-target="#newUser">+ Novo Usuário</button>
                    @endif
                </div>
                <div class="card-body">
                    <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;"
                        role="grid" aria-describedby="datatables-reponsive_info">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Tipo</th>
                                <th>Situação</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                                <tr>
                                    <th>#</th>
                                    <td>{{ $user['name'] }}</td>
                                    <td>{{ $user['email'] }}</td>
                                    <td>
                                        {{ !empty($user['name_permission']) ? $user['name_permission'] : '-' }}
                                    </td>
                                    <td>
                                        <span
                                            class="badge badge-{{ $user['situation'] == 1 ? 'success' : 'danger' }}-light">{{ $user['situation'] == 1 ? 'Ativo' : 'Inativo' }}</span>
                                    </td>
                                    <td>
                                        <button data-bs-toggle="modal" data-bs-target="#editUser{{ $user['id'] }}"
                                            class="ms-2 border-0 bg-transparent"
                                            {{ $user['id'] == Auth::user()->id ? 'disabled' : '' }}
                                            style="{{ $user['id'] == Auth::user()->id ? 'cursor: not-allowed' : '' }}">
                                            <i class="bi bi-pencil-square {{ $user['id'] == Auth::user()->id ? 'text-muted' : 'text-primary' }}"
                                                style="font-size:16px;"></i>
                                        </button>
                                    </td>
                                </tr>

                                <!-- MODAL EDITAR USUARIO -->
                                <div class="modal fade" id="editUser{{ $user['id'] }}" tabindex="-1" role="dialog"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                Alterar Usuário
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            {{-- <form action="{{ route('editUser', $user['id']) }}" method="POST"> --}}
                                            <form action="{{ route('users.update', $user['id']) }}" method="POST">
                                                @csrf
                                                @method('put')
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 mb-3">
                                                            <div class="form-group">
                                                                <label for="name_edit" class="form-label">Nome</label>
                                                                <input type="text" id="name_edit" name="name"
                                                                    class="form-control" placeholder="{{ $user['name'] }}"
                                                                    disabled>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 mb-3">
                                                            <div class="form-group">
                                                                <label for="email_edit" class="form-label">E-mail</label>
                                                                <input type="email" id="email_edit" name="email"
                                                                    class="form-control"
                                                                    placeholder="{{ $user['email'] }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="id_group_edit" class="form-label">Tipo do
                                                                    usuário</label>
                                                                <select name="id_group_edit" id="id_group_edit"
                                                                    class="form-select">
                                                                    <option value=""
                                                                        {{ !empty($user['id_group']) ? 'disabled' : '' }}>
                                                                        Selecione</option>
                                                                    @foreach ($groups as $group)
                                                                        <option
                                                                            {{ $group->id == $user['id_group'] ? 'selected' : '' }}
                                                                            value="{{ $group->id }}">
                                                                            {{ $group->name }}</option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="situation" class="form-label">Situação</label>
                                                                <select name="situation" id="situation"
                                                                    class="form-select">
                                                                    <option value="1"
                                                                        {{ $user['situation'] == 1 ? 'selected' : '' }}>
                                                                        Ativo</option>
                                                                    <option value="0"
                                                                        {{ $user['situation'] == 0 ? 'selected' : '' }}>
                                                                        Inativo</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <input type="hidden" name="id_user"
                                                            value="{{ $user['id'] }}">
                                                    </div>
                                                </div>
                                                <div class="modal-footer d-flex justify-content-end">
                                                    <button type="button" class="btn btn-outline-secondary px-3 btn-sm"
                                                        data-bs-dismiss="modal">Cancelar</button>
                                                    <button type="submit" class="btn btn-warning px-3 btn-sm">Gravar
                                                        Alterações</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- FIM MODAL EDITAR USUARIO -->
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
