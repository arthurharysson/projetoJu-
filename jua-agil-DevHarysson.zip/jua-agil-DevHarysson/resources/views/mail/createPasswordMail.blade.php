<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
        }
    </style>

</head>

<body>
    <div class="wrapper">
        <div class="container" >
            <header class="container-img" style="
                        width: 100%;
                        height: 200px;
                        background-color: #0A2647;
                        border-radius: 0px 0px 100% 100%;
                        text-align: center;
                        margin-bottom: 20px;
                    ">
                <img src="{{ $message->embed(asset('assets/img/LogoJuaOficial.png')) }}" alt="Logo do Sabão Juá" style="padding-top: 60px; width: 120px;">
            </header>
            <main class="container-contents" style="width: 80%; margin:auto; text-align: center;">
                <div class="contents-title">
                    <h2 style="color: #000; text-align: center;">Sistema de Provas - Definir Senha</h2>
                </div>
                <div class="contests-text" style="width: 70%; margin: 20px auto; line-height: 1.5;">
                    <p style="color: #000; margin-bottom: 10px;">
                        Olá, <strong>{{ ucfirst(strtolower($data['name'])) }}</strong>
                    </p>
                    <p style="color: #000;">
                        Este e-mail foi enviado porque você foi cadastrado como usuário no sistema do <strong>Inventário</strong> e é necessário que seja definido uma senha de acesso ao sistema!
                    </p>
                </div>
                <p style="color: #000; text-align: center;"><strong>Clique no botão abaixo para: </strong></p>
                <p class="btn" style="text-align: center; margin-top: 50px;">
                    <a href="{{ route('auth.create', $data['hash']) }}" class="btn-link" style="
                        padding: 10px 20px;
                        border-radius: 5px;
                        text-transform: uppercase;
                        letter-spacing: 1.3px;
                        font-weight: bold;
                        background-color: #2C74B2;
                        text-decoration: none;
                        color: #fff;
                    ">
                        DEFINIR SENHA
                    </a>
                </p>
            </main>
            <footer style="
                        margin-top: 60px;
                        text-align: center;
                        line-height: 1.5;color: #000;
            ">
                <span>Enviado com 💚 pelo Desenvolvimento - Sabão Juá.</span>
                <p>O melhor que há para seu dia a dia.</p>
            </footer>
        </div>
    </div>

</body>

</html>
