<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="icon" type="image/x-icon" href="{{ asset('assets/img/favicon.png') }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    {{-- styles --}}
    <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/bootstrap-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/variables.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/login.css') }}">
</head>

<body>
    <div class="container-fluid">
        <div id="container-content" class="row min-vh-100">
            <div class="col-sm-12 col-md-12 col-lg-6 image-content d-flex gap-4 flex-row flex-md-column align-items-center justify-content-center" style="background-image:url({{ asset('assets/img/Login2.png') }});">
                <img src="{{ asset('assets/img/LogoJuaOficial.png') }}" class="img-fluid img1" alt="" style="filter: drop-shadow(6px 6px 8px rgba(0, 0, 0, 0.25));">
            </div>
            <div class="col-sm-12 col-md-12 col-lg-6 form-area d-flex align-items-center justify-content-center flex-column">
                @yield('form')
            </div>
        </div>
    </div>
</body>
    @include('sweetalert::alert')
    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

    @yield('scripts')
</html>
