<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="icon" href="{{ asset('assets/images/favIconJua.png') }}" title="logo sabão juá">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/variables.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/layout.css') }}">
    @yield('styles')

    <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/bootstrap-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
</head>

<body>
    <div id="app">
        <div class="container-fluid p-0">
            @if (session()->has('menu'))
                @php
                    $sessao = Session::get('menu');
                @endphp
            @endif

            <div class="sidebar close">
                <div class="logo">
                    <img src="{{ asset('assets/img/nova-logo.webp') }}" class="img-fluid" alt="" style="height: 40%;">
                </div>

                <ul class="nav-list">
                    @if ($sessao['view_dashboard'])
                        <li>
                            <a href="{{ route('home') }}" class="{{ (isset($level) && $level == "Dashboard") ? 'active' : ''; }}">
                                <i class="bi bi-graph-up"></i>
                                <span class="link-name">Dashboard</span>
                            </a>

                            <ul class="sub-menu blank">
                                <li><a href="{{ route('home') }}" class="link-name">Dashboard</a></li>
                            </ul>
                        </li>
                    @endif

                    {{-- @if ($sessao['manager_users'] || $sessao['view_parameters'] || $sessao['view_permissions_groups'] || $sessao['manager_categories'] || $sessao['manager_terms'] || $sessao['view_and_modify_system_parameters']) --}}
                        <li class="{{ (isset($level) && $level == "Settings") ? 'active' : ''; }}">
                            <div class="icon-link">
                                <a href="#">
                                    <i class="bi bi-gear-fill"></i>
                                    <span class="link-name">Configurações</span>
                                </a>
                                <i class="bi bi-caret-down-fill arrow"></i>
                            </div>

                            <ul class="sub-menu">
                                <li><a href="#" class="link-name">Configurações</a></li>
                                <li><a href="{{ route('users.index') }}">Usuários</a></li>
                                <li><a href="{{ route('permissions.index') }}">Grupo de permissões</a></li>
                            </ul>
                        </li>

                    {{-- @endif --}}
                </ul>
            </div>
            <div class="home-section d-flex flex-column" style="min-height: 100vh;">
                <div class="home-content d-flex justify-content-between p-3">
                    <div class="d-flex justify-content-center align-items-center gap-2">
                        <i class="bi bi-justify" id="activeMenu"></i>
                    </div>
                    <div class="d-flex justify-content-center align-items-center gap-2">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->name }}
                        </a>

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('auth.logout') }}"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('auth.logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </div>
                </div>
                <div class="container-fluid p-4" style="flex: 1;">
                    @yield('content')
                </div>
                <footer class="bg-white">
                    <div class="container-fluid footer p-3 text-muted">
                        <strong>Copyright &copy; Sabão Juá</strong>
                    </div>
                </footer>
            </div>
        </div>

        @include('sweetalert::alert')

    </div>
</body>

<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/layout.js') }}"></script>
@yield('scripts')
<script src="{{ asset('assets/js/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('assets/js/warnings.js') }}"></script>
</html>
