<style>
    html{
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    table{ 
        text-align: center;
        align-items: center;
        width: 100%;

    }   
    td{
        font-weight: bold;
    }

    th{
        font-weight: normal;
       
    }

    thead{
        padding: 10px;


    }
    #title-card{
        display: flex;
        justify-content: center;
        text-align: center;
        font-weight: bold;

    }

    .card-header button{
        display: flex;
        align-items: flex-end;
        justify-content: center;
    }


   
    .icon-legend{
        width: 40%;
        margin-top: 1rem;
    }

</style>






@extends('layouts.default')

@section('content')
    <!-- Modal para filtrar ordens de produção -->
    <div class="modal fade" id="filtrarModal" tabindex="-1" role="dialog" aria-labelledby="filtrarModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="filtrarModalLabel">Filtrar Ordens de Produção</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="GET" action="{{ route('filtrarOrdens') }}">
                        <div class="form-group">
                            <label for="numero_op">Número da OP</label>
                            <input type="text" class="form-control" name="numero_op" id="numero_op" placeholder="Número da OP">
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status" id="status">
                                <option value="">Selecione o status</option>
                                <option value="NULL">Aguardando</option>
                                <option value="ativa">Em Produção</option>
                                <option value="finalizada">Concluída</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date">Data</label>
                            <input type="date" class="form-control" name="date" id="date">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Botão para abrir a modal de filtro -->
    <div class="card">
        <div class="card-header">
            <div id="title-card">
                <h5>ORDENS DE PRODUÇÃO CADASTRADAS</h5>
            </div>
            
            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#filtrarModal">
                Filtrar
            </button>
         <div id="table-icons"> 
            <table class="icon-legend">
                <thead>
                    <tr>
                        <th><i style="color:blue;" class="bi bi-circle-fill"></i></th>
                        <th><i style="color:#00FF00;" class="bi bi-circle-fill"></i></th>
                        <th><i style="color:yellow;" class="bi bi-circle-fill"></i></th>
                        <th><i style="color:red;" class="bi bi-circle-fill"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Ativa</td>
                        <td>Finalizada</td>
                        <td>Aguardando</td>
                        <td>Parada</td>
                    </tr>
                </tbody>
            </table>
        </div>  
    </div>
        <div class="card-body">
            <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;" role="grid" aria-describedby="datatables-reponsive_info">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Número da OP</th>
                        <th>Código</th>
                        <th>Descrição</th>
                        <th>Método</th>
                        <th>Lote</th>
                        <th>Quantidade prevista</th>
                        <th>UN</th>
                        <th>Linha de Produção</th>
                        <th>Data/Hora</th>
                        <th>Operador</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($ops as $op)
                        @php
                            // Obter o último registro relacionado à OP na tabela ops
                            $lastOp = $ops->where('id', $op->id)->last();

                            // Obter o último log relacionado à OP
                            $lastLog = $logs->where('op_id', $op->id)->last();
                        @endphp
                        <tr>
                            <td>{{ $op->id }}</td>
                            <td>{{ $op->numero_op }}</td>
                            <td>{{ $op->codigo }}</td>
                            <td>{{ $op->descricao }}</td>
                            <td>{{ $op->metodo }}</td>
                            <td>{{ $op->numeroLote }}</td>
                            <td>{{ $op->quantidadePrevista }}</td>
                            <td>{{ $op->un }}</td>
                            <td>{{ $op->linhaProd }}</td>
                            <td>
                                {{ date('d/m/Y', strtotime($op->date)) }} - 
                                {{ \Carbon\Carbon::parse($op->time)->format('H:i') }}
                            </td>
                            <td>{{ $op->operador }}</td>
                    
                            <td>
                                @if ($lastOp->status == 'ativa')
                                    <i style="color:blue;" class="bi bi-circle-fill"></i>
                                @elseif ($lastOp->status == 'finalizada')
                                    <i style="color:#00FF00;" class="bi bi-circle-fill"></i>
                                @elseif (is_null($lastOp->status) && optional($lastLog)->verificarParada == false)
                                    <i style="color:yellow;" class="bi bi-circle-fill"></i>
                                @endif
                                @if (optional($lastLog)->verificarParada == true)
                                    <i style="color:red;" class="bi bi-circle-fill"></i>
                                @endif
                            </td>
                            <td>
                                <form method="GET" action="/home/{{$op->id}}">
                                    <button class="btn btn-primary">Detalhar</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
