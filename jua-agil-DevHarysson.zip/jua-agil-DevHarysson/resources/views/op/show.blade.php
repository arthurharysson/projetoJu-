<style>
    table {
        text-align: center;
        width: 100%;
        margin-bottom: 20px;
    }
    table th, table td {
        padding: 10px;
        border: 1px solid #ddd;
    }
    .alerta {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    #chart_div {
        width: 100%;
        height: 500px;
    }
    #contagemSection, #paradasSection {
        display: none;
        margin-top: 20px;
    }
    .btn-outline-primary {
        margin-bottom: 20px;
    }
    .parada {
        background-color: #f8d7da;
        color: #721c24;
    }
    label {
        display: block;
        margin-top: 11px;
        font-weight: bold;
        color: #0079eb;
        }
    .totalParadas {
        background-color: #f8d7da;
        color: #721c24;
    }

    .btn-form-show {
        display: flex;
    }

    .btn-move {
        padding-right: 2rem;
    }

    .btn-iniciar {
        margin-bottom: 20px;
    }

    #show-btn{
        display: flex;
        margin-top: 15px;
        gap: 15px;
    }

    .card-header{
        text-align: center;
    }

    td{
        font-weight: bold;
    }

    th{
        font-weight: normal;
       
    }

    .total-produzido{
        display: flex;
        justify-content: center;
        font-size: 20px;
        background-color: #21252908;
        border: solid 1px #212529bf;
        border-radius: 5px;
        text-align: center;
        max-width: 280px;
        height: 30px;    
    }

    .rowcab{
        display: flex;
        gap: 50px;
    }

    .cabeçalho{
        background-color: #fff;
        border: 1px solid #0088DD;
        padding:9px;
        border-radius: 19px;
        font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        font-size: 23px;  
        color: #0088DD;    
    }

    .cabeçalho h3{
        font-style: color #0088DD;
    }

</style>



@extends('layouts.default')
@section('content')
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<div class="row">
    @include('components.breadcrumb.breadcrumb', [
        'title' => 'Detalhar',
        'links' => [
            [
                'title' => 'Detalhar',
                'link' => '#',
                'active' => false,
                'is_current' => false,
            ],
            [
                'title' => 'Index',
                'link' => '#',
                'active' => true,
                'is_current' => true,
            ],
        ],
    ])

    <!-- total produzido--->
    @if ($user->id_group == 1 || $user->id_group == 2)
        @php
            $producaoSoma = 0;
            $retrabalhoSoma = 0;
            $count = 0;
        @endphp
        @foreach ($logs as $log)
            @if($log->linhaProd == $linha->linhaProd)
                @php
                    $producaoSoma += $log->producao;
                    $retrabalhoSoma += $log->retrabalho;
                    $log->verificarParada ? ++$count : '-';
                @endphp
            @endif
        @endforeach
        <div class="rowcab">
        <h3 class="cabeçalho">Produzido: {{ $producaoSoma }}</h3>
        <h3 class="cabeçalho">Retrabalho: {{ $retrabalhoSoma }}</h3>
        <h3 class="cabeçalho">
            <td>Paradas: {{ $count }}</td>
        </tr>
        </div>
        
        <div id="chart_div" style="width: 100%; height: 500px;"></div>
        
        <div class="col-12">

            <div id="show-btn">
                    <button type="button" class="btn btn-outline-primary" id="contagemButton">
                        Contagem
                    </button>

                    <button type="button" class="btn btn-outline-primary" id="paradasButton">
                        Paradas
                    </button>
            </div>

            <div id="contagemSection">
                <div class="card">
                    <div class="card-header"><h3>Produção a cada 10 minutos</h3></div>
                    <div class="card-body">
                        <table>
                            <thead>
                                <tr>
                                    <th>Produção</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $producaoSoma = 0;
                                @endphp
                                @foreach ($logs as $log)
                                    @if($log->linhaProd == $linha->linhaProd)
                                        <tr>
                                            <td>{{ $log->producao }}</td>
                                        </tr>
                                        @php
                                            $producaoSoma += $log->producao;
                                        @endphp
                                    @endif
                                @endforeach
                            </tbody>
                        </table>
                        <h3 class="total-produzido">Total Produzido: {{ $producaoSoma }}</h3>
                    </div>
                </div>
            </div>
        </div>

        <div id="paradasSection">
            <div class="card">
                <div class="card-header"><h3>Paradas</h3></div>
                <div class="card-body">
                    <table>
                        <thead>
                            <tr>
                                <th>Número</th>
                                <th>Início</th>
                                <th>Fim</th>
                                <th>Justificativa</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $count = 0;
                            @endphp
                            @foreach ($logs as $key => $log)
                                @if ($log->linhaProd == $linha->linhaProd && $log->verificarParada)
                                    <tr class="parada">
                                        <td>{{ ++$count }}</td>
                                        <td>{{ $log->horario }}</td>
                                        <td>
                                            @php
                                                $horaDeVolta = null;
                                                // Encontra o próximo log que não é parada
                                                for ($i = $key + 1; $i < count($logs); $i++) {
                                                    if (!$logs[$i]->verificarParada && $logs[$i]->linhaProd == $linha->linhaProd) {
                                                        $horaDeVolta = $logs[$i]->horario;
                                                        break;
                                                    }
                                                }
                                            @endphp
                                            {{ $horaDeVolta ?? '-' }}
                                        </td>
                                        <td>
                                            @foreach ($justifies as $justify)
                                                @if ($justify->linhaProd == $linha->linhaProd && $justify->justificativa != ' ')
                                                    <button type="button" class="btn btn-outline-primary justify-button" data-bs-toggle="modal" data-bs-target="#justificativaModal">
                                                        Conferir justificativa
                                                    </button>
                                                @endif
                                                @break
                                            @endforeach
                                        </td>
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                    <h3 class="total-produzido">Total de Paradas: {{ $count }}</h3>
                </div>
            </div>
        </div>
        
        <!-- Modal Conferir Justificativa -->

        <div class="modal fade" id="justificativaModal" tabindex="-1" role="dialog" aria-labelledby="justificativaModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="justificativaModalLabel">Justificativa da Parada</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;" role="grid" aria-describedby="datatables-reponsive_info">
                                    <thead>
                                        <tr>
                                            <th>Código da parada</th>
                                            <th>Etiqueta da máquina</th>
                                            <th>Justificativa</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($justifies as $justify)
                                            @if ($justify->linhaProd == $linha->linhaProd && $justify->justificativa != ' ')
                                                <tr>
                                                    <td>{{ $justify->codigoParada }}</td>
                                                    <td>{{ $justify->tagMaquina }}</td>
                                                    <td>{{ $justify->justificativa }}</td>
                                                </tr>
                                            @endif
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <script type="text/javascript">
            google.charts.load('current', {packages: ['corechart', 'line']});
            google.charts.setOnLoadCallback(drawBackgroundColor);

            function drawBackgroundColor() {
                var data = new google.visualization.DataTable();
                data.addColumn('number', 'Time');
                data.addColumn('number', 'Produção');
            
                var chartData = [
                    @php
                        $time = 0;
                    @endphp
                    [{{ $time }}, 0],
                    @foreach ($logs as $log)
                        @php
                            $time += 10;
                        @endphp
                        @if ($linha->linhaProd == $log->linhaProd)
                            [{{ $time }}, {{ $log->producao }}],
                        @endif
                    @endforeach
                ];

                data.addRows(chartData);

                var options = {
                    hAxis: {
                        title: 'Time'
                    },
                    vAxis: {
                        title: 'Produção'
                    },
                    backgroundColor: 'default'
                };

                var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
                chart.draw(data, options);
            }

            document.getElementById('paradasButton').addEventListener('click', function() {
                var paradasSection = document.getElementById('paradasSection');
                if (paradasSection.style.display === 'none' || paradasSection.style.display === '') {
                    paradasSection.style.display = 'block';
                } else {
                    paradasSection.style.display = 'none';
                }
            });

            document.getElementById('contagemButton').addEventListener('click', function() {
                var contagemSection = document.getElementById('contagemSection');
                if (contagemSection.style.display === 'none' || contagemSection.style.display === '') {
                    contagemSection.style.display = 'block';
                } else {
                    contagemSection.style.display = 'none';
                }
            });
        </script>
    @else

                        <!-- Início "Detalhar" do operador -->
    @php
        $producaoSoma = 0;
        $retrabalhoSoma = 0;
        $count = 0;
    @endphp
    @foreach ($logs as $log)
        @if($log->linhaProd == $linha->linhaProd)
            @php
                $producaoSoma += $log->producao;
                $retrabalhoSoma += $log->retrabalho;
                $log->verificarParada ? ++$count : '-';
            @endphp
        @endif
    @endforeach
    
    <div class="rowcab">
        <h3 class="cabeçalho">Produzido: {{ $producaoSoma }}</h3>
        <h3 class="cabeçalho">Retrabalho: {{ $retrabalhoSoma }}</h3>
        <h3 class="cabeçalho">
            <td>Paradas: {{ $count }}</td>
        </tr>
        </div>
        
        <div class="card">
            <div class="card-body">
                <div class="col-12">
                    <form method="POST" action="{{ route('status.update', ['id' => $linha->id]) }}">
                        @csrf
                        <div class="btn-iniciar">
                            <input type="hidden" name="status" value="ativa">
                            <button type="submit" class="btn btn-primary">Iniciar</button>
                        </div>
                    </form>
                    <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;" role="grid" aria-describedby="datatables-reponsive_info">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Número da OP</th>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th>Método</th>
                                <th>Lote</th>
                                <th>Quantidade prevista</th>
                                <th>UN</th>
                                <th>Linha de produção</th>
                                <th>Operador</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{ $linha->id }}</td>
                                <td>{{ $linha->numero_op }}</td>
                                <td>{{ $linha->codigo }}</td>
                                <td>{{ $linha->descricao }}</td>
                                <td>{{ $linha->metodo }}</td>
                                <td>{{ $linha->numeroLote }}</td>
                                <td>{{ $linha->quantidadePrevista }}</td>
                                <td>{{ $linha->un }}</td>
                                <td>{{ $linha->linhaProd }}</td>
                                <td>{{ $linha->operador }}</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="btn-form-show">
                        <form method="POST" action="{{ route('status.update', ['id' => $linha->id]) }}">
                            @csrf
                            <div class="btn-move">
                                <input type="hidden" name="status" value="finalizada">
                                <button type="submit" class="btn btn-primary">Encerrar</button>
                            </div>
                        </form>
                        <button type="button" class="btn btn-outline-primary" id="paradasButton">
                            Status
                        </button>
                    </div>
                </div>
            </div>
        </div>




        <!-- <div class="card">
            <div class="card-body">
                <div class="col-12">
                    <table class="table dataTable table-hover table-striped" id="dataTables-responsive" style="width: 100%;" role="grid" aria-describedby="datatables-reponsive_info">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Produção</th>
                                <th>Horario que parou</th>
                                <th>Horario que voltou a funcionar</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($logs as $log)
                                @if ($linha->linhaProd == $log->linhaProd)
                                    <tr class="{{ $log->verificarParada ? 'parada' : '' }}">
                                        <td>{{ $log->verificarParada ? 'Parada' : 'Ativa' }}</td>
                                        <td>{{ $log->producao ?? '-' }}</td>
                                        @if ($log->verificarParada)
                                            <td>{{ $log->horario ?? '-' }}</td>
                                        @else
                                            <td> - </td>
                                        @endif
                                        @if (!$log->verificarParada)
                                            <td>{{ $log->horario ?? '-' }}</td>
                                        @else
                                            <td> - </td>
                                        @endif
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        -->









        <div id="paradasSection">
            <div class="card">
                <div class="card-header"><h3>Paradas</h3></div>
                <div class="card-body">
                    <table>
                        <thead>
                            <tr>
                                <th>Número</th>
                                <th>Status</th>
                                <th>Produção</th>
                                <th>Retrabalho</th>
                                <th>Parou</th>
                                <th>Funcionou</th>
                                <th> </th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $count = 0;
                            @endphp
                            @foreach ($logs as $log)
                                @if ($linha->linhaProd == $log->linhaProd)
                                    <tr class="{{ $log->verificarParada ? 'parada' : '' }}">
                                        <td>{{ $log->verificarParada ? ++$count : '-' }}</td>
                                        <td>{{ $log->verificarParada ? 'Parada' : 'Ativa' }}</td>
                                        <td>{{ $log->producao ?? '-' }}</td>
                                        <td>{{$log->retrabalho}}</td>
                                        @if ($log->verificarParada)
                                            <td>{{ $log->horario ?? '-' }}</td>
                                        @else
                                            <td> - </td>
                                        @endif
                                        @if (!$log->verificarParada)
                                            <td>{{ $log->horario ?? '-' }}</td>
                                        @else
                                            <td> - </td>
                                        @endif
                                        @if($log->verificarParada)
                                            <td>
                                                <button type="button" class="btn btn-outline-primary justify-button" data-bs-toggle="modal" data-bs-target="#justificarModal" data-codigo-parada="{{ $log->codigoParada }}" data-tag-maquina="{{ $log->tagMaquina }}">
                                                    Justificar
                                                </button>
                                            </td>
                                        @else
                                            <td> - </td>
                                        @endif
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                    <table>
                        <tbody>
                            <tr class="totalParadas">
                                <td>Total de paradas: {{ $count }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="justificarModal" tabindex="-1" role="dialog" aria-labelledby="justificarModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="justificarModalLabel">Justificar Parada</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Formulário dentro do modal -->
                        <form method="POST" action="/justify">
                            @csrf
                            <div class="form-group">
                                <label for="codigoParada">código parada</label>
                                <select class="form-control" name="codigoParada" id="codigoParada">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tagMaquina">Etiqueta da Máquina</label>
                                <input type="text" class="form-control" id="tagMaquina" name="tagMaquina" required>
                            </div>
                            <div class="form-group">
                                <label for="justificativa">Justificativa</label>
                                <textarea class="form-control" id="justificativa" name="justificativa" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="linhaProd">Linha de produção</label>
                                <select class="form-control" name="linhaProd" id="linhaProd">
                                    <option selected>Linha de Produção</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                </select>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                <button type="submit" class="btn btn-primary">Salvar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            document.getElementById('paradasButton').addEventListener('click', function() {
                var paradasSection = document.getElementById('paradasSection');
                if (paradasSection.style.display === 'none' || paradasSection.style.display === '') {
                    paradasSection.style.display = 'block';
                } else {
                    paradasSection.style.display = 'none';
                }
            });

            document.querySelectorAll('.justify-button').forEach(function(button) {
                button.addEventListener('click', function() {
                    var codigoParada = this.getAttribute('data-codigo-parada');
                    var tagMaquina = this.getAttribute('data-tag-maquina');
                    document.getElementById('codigoParada').value = codigoParada;
                    document.getElementById('tagMaquina').value = tagMaquina;
                });
            });
        </script>
    @endif
</div>
@endsection