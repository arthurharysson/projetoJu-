@extends('layouts.default')
@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juá Ágil</title>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>
        html {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        .alerta {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 20px;
            padding: 20px;
            border-radius: 5px;
            background-color: #f8d7da;
            color: #721c24;
        }

        #chart_div, #donutchart {
            width: 500px;
            height: 300px;
            margin: 20px;
        }

        .dashboard-charts {
            display: flex;
            justify-content: center;
            align-items: center;
            max-height: 400px;
        }

        .separator {
            width: 1px;
            height: 500px;
            background-color: #ddd;
            margin-bottom: 7px;
        }

        table {
            text-align: center;
            width: 100%;
        }

        td {
            font-weight: bold;
        }

        th {
            font-weight: normal;
        }

        thead {
            padding: 100px;
        }

        .ppop {
            display: flex;
            flex-direction: row;
        }

        .ppop h1 {
            align-items: center;
            text-align: center;
        }

        .card-title-mb-0 {
            text-align: center;
            padding: 10px;
        }

        .modal-alert .modal-content {
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 5px;
        }

        .modal-header, .modal-footer {
            border: none;
        }

        .titleCharts {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }

        .titleCharts div {
            background-color: #fff;
            text-align: center;
            width: 600px;
            padding: 10px;
        }
    </style>
</head>
<body>



    <div class="container">
        @include('components.breadcrumb.breadcrumb', [
            'title' => 'Dashboard',
            'links' => [
                [
                    'title' => 'Dashboard',
                    'link' => '#',
                    'active' => false,
                    'is_current' => false,
                ],
                [
                    'title' => 'Index',
                    'link' => '#',
                    'active' => true,
                    'is_current' => true,
                ],
            ],
        ])

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <form method="GET" action="/listar-ops">
                        <button class="btn btn-primary">Listar ordens de produção</button>
                    </form>
                </div>
                <div class="card-body">
                    <div class="titleCharts">
                        <div id="title1"><h2>Produção total</h2></div>
                        <div id="title2"><h2>Produção por Operador</h2></div>
                    </div>
                    <div class="dashboard-charts">
                        <div id="chart_div"></div>
                        <div class="separator"></div>
                        <div id="donutchart"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Alerta -->
    <div class="modal fade modal-alert" id="alertModal" tabindex="-1" role="dialog" aria-labelledby="alertModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="alertModalLabel">Atenção!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="alertMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráfico 1 -->
    <script type="text/javascript">
        google.charts.load('current', { packages: ['corechart', 'line'] });
        google.charts.setOnLoadCallback(drawBackgroundColor);

        function drawBackgroundColor() {
            var data = new google.visualization.DataTable();
            data.addColumn('number', 'Tempo');
            data.addColumn('number', 'Produção');

            var chartData = [
                @php $time = 0; @endphp
                [{{ $time }}, 0],
                @foreach ($logs as $log)
                    @php $time += 10; @endphp
                    [{{ $time }}, {{ $log->producao }}],
                @endforeach
            ];

            data.addRows(chartData);

            var options = {
                hAxis: { title: 'Tempo' },
                vAxis: { title: 'Produção' },
                backgroundColor: 'default',
            };

            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>

    <!-- Gráfico 2 -->
    <script type="text/javascript">
        google.charts.load("current", { packages: ["corechart"] });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var dataArray = [['Operador', 'Total produzido até o momento']];
            
            @foreach ($operadorProds as $op)
                dataArray.push(['{{ $op->operador }}', {{ $op->total_producao }}]);
            @endforeach
            
            var data = google.visualization.arrayToDataTable(dataArray);

            var options = {
                title: 'Produção por Operador',
                pieHole: 0.2,
                
            };

            var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
            chart.draw(data, options);
        }

        document.addEventListener('DOMContentLoaded', function () {
            var logs = @json($logs);
            if (logs.length > 0) {
                var lastLog = logs[logs.length - 1];
                if (lastLog.verificarParada) {
                    $('#alertMessage').text('A linha de produção ' + lastLog.linhaProd + ' está parada');
                    $('#alertModal').modal('show');
                }
            }
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

@endsection
