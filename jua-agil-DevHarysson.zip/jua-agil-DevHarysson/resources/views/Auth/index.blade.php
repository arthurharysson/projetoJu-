@extends('layouts.auth')

@section('form')
    <form method="POST" class="d-flex flex-column justify-content-center align-items-center pt-2 pb-4" action="{{ route('auth.login') }}">
        @csrf
        <div class="d-flex gap-3 align-items-center justify-content-center">
            <h3 class=" text-center m-0">Bem-vindo ao sistema</h3>
        </div>
        <div class="mt-4 w-100 form-group">
            <input type="email" name="email" id="email" class="form-control p-3 @error('email') is-invalid @enderror" required
                placeholder="Email" autocomplete="off" autofocus value="{{ old('email') }}">
        </div>
        <div class="w-100 mt-4 p-3 d-flex align-items-center form-group-password" id="inputPassword" style="max-height: 57.02px">
            <input type="password" name="password" id="pass" class="w-100 border-0" required
                placeholder="Senha" autocomplete="off" autofocus value="{{ old('password') }}">
            <label for="password">
                <i id="icon" class="bi bi-eye-fill" title="Mostrar senha"></i>
            </label>
        </div>
        <div class="form-link w-100 text-end mt-3">
            <a class="text-decoration-none" href="{{ route('auth.reset') }}">Esqueceu sua senha?</a>
        </div>
        <div class="mt-4 w-100 text-center">
            <button type="submit" class="btn fw-semibold fs-5 py-2 text-white">Entrar</button>
        </div>
    </form>
@endsection

@section('scripts')
    <script src="{{ asset('assets/js/jquery-3.5.1.js') }}"></script>
    <script src="{{ asset('assets/js/login.js') }}"></script>
@endsection
