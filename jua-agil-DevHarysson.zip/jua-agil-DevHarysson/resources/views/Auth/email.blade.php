@extends('layouts.auth')

@section('form')
    <form action="{{ route('password.reset') }}" method="POST" class="d-flex flex-column justify-content-center align-items-center">
        @csrf
        <div class="d-flex gap-3 align-items-center justify-content-center">
            <h3 class="fw-bolder text-center m-0">Recuperar Senha</h3>
        </div>
        <div class="mt-4 w-100 form-group">
            <input type="email" name="email" id="Email" class="form-control p-3" required
                placeholder="Email" autocomplete="off" autofocus>
        </div>
        <div class="form-link w-100 text-end mt-3">
            <a class="text-decoration-none" href="{{ route('login') }}">Voltar para o login</a>
        </div>
        <div class="mt-4 w-100 text-center">
            <button type="submit" class="btn fw-semibold fs-5 py-2 text-white">Solicitar redefinição de senha</button>
        </div>
    </form>
@endsection
