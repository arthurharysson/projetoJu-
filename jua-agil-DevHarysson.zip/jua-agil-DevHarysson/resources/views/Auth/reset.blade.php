@extends('layouts.auth')

@section('form')
    <form method="POST" id="formRedefinir" class="d-flex flex-column justify-content-center align-items-center" action="{{ route('password.update') }}">
        @csrf
        <div class="d-flex gap-3 align-items-center justify-content-center">
            <h3 class="fw-bolder text-center m-0">Redefinição de Senha</h3>
        </div>
        <input type="hidden" name="hash" value="{{ $hash }}">
        <div class="w-100 mt-4 p-3 d-flex align-items-center form-group-password" id="inputPassword" style="max-height: 57.02px">
            <input type="text" name="pass" id="pass" class="w-100 border-0 newPass" required
                placeholder="Nova Senha" autocomplete="off" value="{{ old('pass') }}">
            <label for="pass">
                <i id="icon" class="bi bi-eye-fill" title="Ocultar senha"></i>
            </label>
        </div>
        <div class="col-md-12 mt-1">
            <span style="font-size: 12px;color: #a9a6a6;">
                Requisitos de senha: Ter
                <span id="number">números</span>,
                <span id="lower">letras minusculas</span>,
                <span id="upper">letras maiúsculas</span>,
                <span id="character">caracteres especiais (!,@,#,$,%)</span> e
                <span id="qtd_character">no mínimo 8 caracteres</span>
            </span>
        </div>
        <div class="w-100 mt-4 p-3 d-flex align-items-center form-group-password" id="inputPasswordConfirm" style="max-height: 57.02px">
            <input type="text" name="password_confirm" id="password_confirm" class="w-100 border-0" required
                placeholder="Confirme nova senha" autocomplete="off" value="{{ old('password_confirm') }}">
            <label for="password_confirm">
                <i id="iconConfirmPassword" class="bi bi-eye-fill" title="Ocultar senha"></i>
            </label>
        </div>
        <div class="mt-4 w-100 text-center">
            <button type="submit" class="btn fw-semibold fs-5 py-2 text-white">
                Redefinir Senha
            </button>
        </div>
    </form>
@endsection

@section('scripts')
    <script src="{{ asset('assets/js/jquery-3.5.1.js') }}"></script>
    <script src="{{ asset('assets/libs/sweetalert/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('assets/libs/sweetalert/warnings.js') }}"></script>
    <script src="{{ asset('assets/js/login.js') }}"></script>
@endsection
