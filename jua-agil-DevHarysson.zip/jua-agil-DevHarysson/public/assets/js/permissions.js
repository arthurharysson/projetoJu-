function editPermission(obj) {
    id = $(obj).attr('data-id')
    name = $(obj).attr('data-name')
    description = $(obj).attr('data-description')
    route_name = $(obj).attr('data-route-name');
    menu_group = $(obj).attr('data-menu-group');

    $('#offcanvasRightEdit').toggleClass('show')

    $('#id_edit').val(id)
    $('#paramNameEdit').val(name)
    $('#paramDescriptionEdit').val(description)
    $('#paramRouteNameEdit').val(route_name)

    var selectedValue = menu_group;
    var selectElement = document.getElementById("floatingSelectMenuGroup");
    for (var i = 0; i < selectElement.options.length; i++) {
        if (selectElement.options[i].value === selectedValue) {
            selectElement.options[i].selected = true;
            break;
        }
    }
}

function editGroup(obj) {
    id = $(obj).attr('data-id')
    name = $(obj).attr('data-name')
    params = $(obj).attr('data-params')

    $('#offcanvasRightEditTwo').toggleClass('show')

    $('#id_group_edit').val(id)
    $('#groupNameEdit').val(name)

    parameters = document.querySelectorAll('.parameter')
    parameters.forEach(element => {
        $(element).removeAttr('checked')
    });

    activeParameters = params.split(',')
    activeParameters.forEach(element => {
        $(`#paramEdit${element}`).attr('checked', 'checked')
    });

    qtdCollapse = document.querySelectorAll('.collapse');
    qtdCollapse.forEach(element => {
        $(element).removeClass('show')
    })

}

function closeOffCanvas(obj) {
    id = $(obj).attr('data-id')

    $(`#${id}`).toggleClass('show')
}
