
$('#icon').on('click', function() {
    $('#icon').toggleClass('bi-eye-slash-fill');
    $('#icon').toggleClass('bi-eye-fill');

    if ($('#pass').attr('type') == 'password') {
        $('#pass').attr('type', 'text');
        $('#icon').attr('title', 'Ocultar senha');
    } else {
        $('#pass').attr('type', 'password');
        $('#icon').attr('title', 'Mostrar senha');
    }
})

$('#iconConfirmPassword').on('click', function() {
    $('#iconConfirmPassword').toggleClass('bi-eye-slash-fill');
    $('#iconConfirmPassword').toggleClass('bi-eye-fill');

    if ($('#password_confirm').attr('type') == 'password') {
        $('#password_confirm').attr('type', 'text');
        $('#iconConfirmPassword').attr('title', 'Ocultar senha');
    } else {
        $('#password_confirm').attr('type', 'password');
        $('#iconConfirmPassword').attr('title', 'Mostrar senha');
    }
})


$(document).ready(function() {
    $('#pass').focus(function() {
        $('#inputPassword').addClass('focus');
    });

    $('#pass').blur(function() {
        $('#inputPassword').removeClass('focus');
    });

    $('#password_confirm').focus(function() {
        $('#inputPasswordConfirm').addClass('focus');
    });

    $('#password_confirm').blur(function() {
        $('#inputPasswordConfirm').removeClass('focus');
    });
})

$("#formRedefinir").on("submit", function(event) {
    if ($(`#pass`).val() !== $(`#password_confirm`).val()) {
        event.preventDefault();
        warnings('DifferentPasswords');
    }
});

$('.newPass').on('keyup', function () {
    strongPassword()
})

function strongPassword() {
    if ($(".newPass").val().match(numbers)) {
        $("#number").css("color", "#03AC13");
    } else {
        $("#number").css("color", "#a9a6a6");
    }

    if ($(".newPass").val().match(lower)) {
        $("#lower").css("color", "#03AC13");
    } else {
        $("#lower").css("color", "#a9a6a6");
    }

    if ($(".newPass").val().match(upper)) {
        $("#upper").css("color", "#03AC13");
    } else {
        $("#upper").css("color", "#a9a6a6");
    }

    if ($(".newPass").val().match(ChEspeciais)) {
        $("#character").css("color", "#03AC13");
    } else {
        $("#character").css("color", "#a9a6a6");
    }

    if ($(".newPass").val().length >= 8) {
        $("#qtd_character").css("color", "#03AC13");
    } else {
        $("#qtd_character").css("color", "#a9a6a6");
    }
}

let numbers = /([0-9])/;
let lower = /([a-z])/;
let upper = /([A-Z])/;
let ChEspeciais = /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/;
