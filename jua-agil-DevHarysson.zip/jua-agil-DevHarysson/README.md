<p align="center">
  <img src="./public/assets/img/LogoJuaOficial.png" width="200" alt="Logo Juá">
</p>

<h2 align="center">💻 PASSO A PASSO DA INSTALAÇÃO E CONFIGURAÇÃO DO SISTEMA 💻</h2>

## Sumário
- [Sumário](#sumário)
- [Pré-requisitos](#pré-requisitos)
- [Configuração do Projeto](#configuração-do-projeto)
  - [Após ter feito o clone do repositório, acesse a pasta do projeto:](#após-ter-feito-o-clone-do-repositório-acesse-a-pasta-do-projeto)
  - [Crie um arquivo .env a partir do arquivo .env.example](#crie-um-arquivo-env-a-partir-do-arquivo-envexample)
  - [Em seguida inicie o container Docker:](#em-seguida-inicie-o-container-docker)
  - [Acesse o container:](#acesse-o-container)
  - [Gere a key do projeto laravel:](#gere-a-key-do-projeto-laravel)
  - [Ainda dentro do terminal rode o comando para criar as migrations do banco de dados:](#ainda-dentro-do-terminal-rode-o-comando-para-criar-as-migrations-do-banco-de-dados)
  - [O banco criado, conta com um usuário para testes com as seguintes credenciais:](#o-banco-criado-conta-com-um-usuário-para-testes-com-as-seguintes-credenciais)
  - [Caso você vá utilizar o storage do laravel, rode esse comando:](#caso-você-vá-utilizar-o-storage-do-laravel-rode-esse-comando)
  - [Acesse o projeto pela url:](#acesse-o-projeto-pela-url)

## Pré-requisitos
Certifique-se de ter o Docker instalado em sua máquina.

## Configuração do Projeto

### Após ter feito o clone do repositório, acesse a pasta do projeto:
```sh
$ cd nome-do-projeto
```
### Crie um arquivo .env a partir do arquivo .env.example
```sh
$ cp .env.example .env
# Ou copie o arquivo .env.example e renomeie o arquivo copiado para .env
```
### Em seguida inicie o container Docker:
```sh
$ docker-compose up -d
```
### Acesse o container:
```sh
$ docker-compose exec app bash
```
### Gere a key do projeto laravel:
```sh
$ php artisan key:generate
```
### Ainda dentro do terminal rode o comando para criar as migrations do banco de dados:
```sh
$ php artisan migrate --seed
```
### O banco criado, conta com um usuário para testes com as seguintes credenciais:
```sh
user: admin@gmail.com 
pass: 123
```
### Caso você vá utilizar o storage do laravel, rode esse comando:
```sh
$ php artisan storage:link
```
### Acesse o projeto pela url:
<a href="http://localhost:8000">Link do projeto</a>


